# 転べ！叫べ！生きろ！ - ZINE Web

Next.js + Tailwindで構築されたZINE形式のWebサイト試作です。
